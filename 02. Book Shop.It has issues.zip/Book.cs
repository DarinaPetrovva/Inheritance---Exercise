﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop
{
    public class Book
    {
        public string title;
        public string author;
        public decimal price;


        public string Title
        {
            get { return title; }
            set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Title not valid!");
                }
                title = value;
            }
        }

        public string Author
        {
            get { return author; }
            set
            {
                var names = value.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (char.IsDigit(names[1][0]))
                {
                    throw new ArgumentException("Author not valid!");
                }
                author = value;
            }
        }

        public virtual decimal Price
        {
            get { return price; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("Price not valid!");
                }
               price = value;
            }
        }

        public Book(string author, string title, decimal price)
        {
            Author = author;
            Title = title;
            Price = price;
        }

        public override string ToString()
        {


            var resultBuilder = new StringBuilder();
            resultBuilder.AppendLine($"Type: {GetType().Name}")
                .AppendLine($"Title: {Title}")
                .AppendLine($"Author: {Author}")
                .AppendLine($"Price: {Price:f2}");

            string result = resultBuilder.ToString().TrimEnd();
            return result;


        }
    }
}

